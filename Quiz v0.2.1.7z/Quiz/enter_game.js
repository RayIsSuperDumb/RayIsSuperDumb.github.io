function submit() {
            // Get the input value
            const inputValue = document.getElementById("inputValue").value;

            // Send the message to the server using the fetch API
            fetch('/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: 'search_game',
                    value: inputValue
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Message sent:', data);

                // Display the server response in the page
                document.getElementById('response').innerText = "Message sent: " + data.result;

                // Check if the response result is "True"
                if (data.result === "True") {
                    // Redirect to the new URL based on the input value
                    if ("redirect" in data) {
                        window.location.href = data.redirect
                    }
                } else {
                    // If result is not "True", show a failure message
                    alert("Invalid message");
                }
            })
            .catch(error => {
                console.error('Error sending message:', error);
                alert("Server Error");
            });
        }