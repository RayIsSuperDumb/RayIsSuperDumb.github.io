from flask import Flask, send_file, send_from_directory, request, jsonify
from game import*

games = {114514:Game("None")}


app = Flask(__name__)



@app.route('/')
def home():
    return send_file('enter_game.html')



@app.route('/file/<filename>')
def serve_file(filename):
    print(filename, "is sent to user")
    return send_file(filename)



@app.route('/message', methods=['POST'])
def handle_request():
    message = request.json

    

    if message["name"] == "search_game":

        print(f"Message from <unknown user>: {message}")

        try:
            int(message['value'])

        except:

            print("Invalid roomid")
            return jsonify({"result": "False"})
        
        if len(message['value']) == 6 and int(message['value']) in games:#and code in list of game code
            print("Valid roomid")
            return jsonify({"result": "True", "redirect": "/room/" + message['value']})

        else:
            print("Invalid roomid")
            return jsonify({"result": "False"})

    elif message["name"] == "add_player":
        
        if "roomid" in message.keys():
            
            print("{message['value']} requests to add into room " + message["roomid"])
            
            roomid = int(message["roomid"])
            if roomid in games:
                result = games[roomid].add_player(message["value"])
                if result["result"]:
                    print(f"{message['value']} is added into room {message['roomid']} with player id {result['id']}")
                    
                    return jsonify({"result": "True", "redirect": f"/room/{message['roomid']}/{result['id']}"})

                else:
                    return jsonify({"result": "False"})
            else:
                return jsonify({"result": "False"})
        else:
            return jsonify({"result": "False"})




@app.route('/room/<room_code>/')
def enter_game(room_code):
    try:
        room_code = int(room_code)

    except:
        return 'Room ID invalid'
    
    if int(room_code) in games:
        return send_file('room_landing.html')

    else:
        return 'Room ID does not exist'

@app.route('/room/<room_code>/<pid>')
def in_game(room_code,pid):

    return send_file('in_game.html')
    

    

app.run(host="0.0.0.0", debug=False)
