import tkinter as tk
import random
import time as t
import asyncio

question_file_name="questions.txt"
 
class Game:
    def __init__(self,admin_username):
 
        self.questions = self.load_questions("questions.txt")
        self.asked_questions = set()
 
        self.players = {}
        self.admin = admin_username
 
        self.status = 0
 
        self.questions = self.load_questions("questions.txt")
 

    def start(self):
        if not self.status:
            self.status = 1


 
    def load_questions(self, filename):
        questions = []
        with open(question_file_name, "r", encoding='utf-8') as f:
            for line in f:
                question, answers = line.strip().split("|")
                answers_list = [answer.strip() for answer in answers.split(",")]
                questions.append({"question": question, "answers": answers_list})
        return questions
 
    def add_player(self, player_username):
        
        if not self.status:
            player_id = random.randint(10000, 99999)
            
            if player_id in self.players.keys() or player_username in self.players.values():
                return "Player ID or Username already exists"
            
            self.players[player_id] = player_username
            
            return {"result":True, "id":player_id}
        return {"result":False}
 
 
    def generate_question(self):
        if len(self.asked_questions) >= len(self.questions):
            #END()
            pass
 
        while True:
            question = random.choice(self.questions)
            question_index = self.questions.index(question)
 
            if question_index not in self.asked_questions:
                self.asked_questions.add(question_index)
                break
 
        return question
 
 
    def rush(self, player):
        pass
    def send_question(self):
        pass
 
    def start_answer(self):
        pass

def main():
    global app

    app = Game("abc")
    
    while True:
        question = app.generate_question()
        app.send_question()
        app.start_answer()



        break

    
 
 
 
if __name__ == "__main__":
    main()
